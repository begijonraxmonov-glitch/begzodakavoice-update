import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import urllib.request
from datetime import datetime
import tkinter as tk
from tkinter import messagebox

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE_DIR, "launcher_db.json")
SESSION_FILE = os.path.join(BASE_DIR, "session.json")
MODS_DIR = os.path.join(BASE_DIR, "mods")

APP_VERSION = "1.0.1"
# Bu yerga onlayn version.json havolasini qo'yasiz.
# Masalan: "https://raw.githubusercontent.com/USERNAME/begzodakavoice-update/main/version.json"
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/begijonraxmonov-glitch/begzodakavoice-update/refs/heads/main/version.json"

BRAND_NAME = "begzodakavoice"
WINDOW_TITLE = f"{BRAND_NAME} — O'yin Tarjimalari Launcher"

GAMES_CATALOG = [
    {
        "id": "shrek2",
        "title": "Shrek 2 Remastered",
        "genre": "Sarguzasht · O'zbekcha ovoz (MP3)",
        "price": "25 000 so'm",
        "status": "available",
        "accent": "#15803d",
    },
    {
        "id": "asterix",
        "title": "Astérix & Obélix XXL",
        "genre": "Ekshn · O'zbekcha ovoz",
        "price": "20 000 so'm",
        "status": "available",
        "accent": "#b45309",
    },
    {
        "id": "cs16_uz",
        "title": "Counter-Strike 1.6 UZ",
        "genre": "Otishma · Maxsus xarita",
        "price": "Bepul",
        "status": "available",
        "accent": "#1d4ed8",
    },
    {
        "id": "soon_game",
        "title": "Yangi loyiha",
        "genre": "Tez kunda tayyor bo'ladi",
        "price": "Tez kunda",
        "status": "coming_soon",
        "accent": "#334155",
    },
]


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def load_db() -> dict:
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and "users" in data:
                    data.setdefault("purchases", [])
                    data.setdefault("game_paths", {})
                    data.setdefault("installed", [])
                    return data
        except Exception:
            pass
    return {"users": [], "purchases": [], "game_paths": {}, "installed": []}


def save_db(data: dict) -> None:
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_session() -> str | None:
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                email = data.get("email")
                if email:
                    return email.strip()
        except Exception:
            pass
    return None


def save_session(email: str | None) -> None:
    try:
        if email:
            with open(SESSION_FILE, "w", encoding="utf-8") as f:
                json.dump({"email": email.strip()}, f, ensure_ascii=False, indent=2)
        elif os.path.exists(SESSION_FILE):
            os.remove(SESSION_FILE)
    except Exception:
        pass


def parse_version(ver: str) -> tuple[int, ...]:
    parts = []
    for p in str(ver).strip().split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    return tuple(parts)


class BegzodakaVoiceLauncher:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(WINDOW_TITLE)
        self.root.geometry("1120x720")
        self.root.minsize(900, 600)
        self.root.configure(bg="#0b0e14")

        self.db = load_db()
        self.current_user = None
        self.active_filter = "all"
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self.render_main_screen())

        self.update_available = False
        self.latest_version = APP_VERSION
        self.update_notes = ""
        self.download_url = ""

        saved_email = load_session()
        if saved_email:
            for user in self.db["users"]:
                if user.get("email", "").strip().lower() == saved_email.lower():
                    self.current_user = user
                    break

        if self.current_user:
            self.render_main_screen()
        else:
            self.render_auth_screen(mode="register")

        if UPDATE_MANIFEST_URL:
            threading.Thread(target=self._check_update_background, daemon=True).start()

    def _check_update_background(self) -> None:
        try:
            with urllib.request.urlopen(UPDATE_MANIFEST_URL, timeout=6) as resp:
                info = json.loads(resp.read().decode("utf-8"))
            latest_ver = str(info.get("version", "")).strip()
            notes = str(info.get("notes", "Yangi versiya chiqdi.")).strip()
            url = str(info.get("download_url", "")).strip()
            if latest_ver and parse_version(latest_ver) > parse_version(APP_VERSION):
                self.update_available = True
                self.latest_version = latest_ver
                self.update_notes = notes
                self.download_url = url
                self.root.after(0, self._on_update_found)
        except Exception:
            pass

    def _on_update_found(self) -> None:
        if self.current_user:
            self.render_main_screen()
        ans = messagebox.askyesno(
            "Yangilanish mavjud (Obnovit)",
            f"Joriy versiya: {APP_VERSION}\n"
            f"Yangi versiya: {self.latest_version}\n\n"
            f"{self.update_notes}\n\n"
            f"Hozir yangilashni (Obnovit) xohlaysizmi?",
        )
        if ans:
            self.start_update()

    def start_update(self) -> None:
        if not self.download_url:
            messagebox.showinfo(
                "Yangilanish",
                "Yangilash havolasi hali kiritilmagan.",
            )
            return

        if not getattr(sys, "frozen", False):
            messagebox.showinfo(
                "Ma'lumot",
                f"Yangi versiya ({self.latest_version}) tayyor!\n"
                f"Yuklash havolasi:\n{self.download_url}",
            )
            return

        current_exe = sys.executable
        new_exe = current_exe + ".new"
        bat_path = os.path.join(os.path.dirname(current_exe), "update_launcher.bat")

        def worker() -> None:
            try:
                urllib.request.urlretrieve(self.download_url, new_exe)
                bat_content = (
                    "@echo off\r\n"
                    "timeout /t 2 /nobreak >nul\r\n"
                    f'move /y "{new_exe}" "{current_exe}" >nul\r\n'
                    f'start "" "{current_exe}"\r\n'
                    'del "%~f0"\r\n'
                )
                with open(bat_path, "w", encoding="utf-8") as bf:
                    bf.write(bat_content)

                def finish_launch() -> None:
                    subprocess.Popen(
                        ["cmd.exe", "/c", bat_path],
                        creationflags=subprocess.CREATE_NO_WINDOW,
                    )
                    self.root.destroy()

                self.root.after(0, finish_launch)
            except Exception as e:
                self.root.after(
                    0,
                    lambda: messagebox.showerror(
                        "Xatolik", f"Yangilashda xato yuz berdi: {e}"
                    ),
                )

        messagebox.showinfo(
            "Yangilanmoqda",
            "Yangi versiya yuklanmoqda. Iltimos, biroz kuting...",
        )
        threading.Thread(target=worker, daemon=True).start()

    def clear_window(self) -> None:
        for widget in self.root.winfo_children():
            widget.destroy()

    def get_user_purchased_ids(self) -> set[str]:
        if not self.current_user:
            return set()
        email = self.current_user["email"].lower()
        return {
            p["game_id"]
            for p in self.db["purchases"]
            if p.get("user_email", "").lower() == email
        }

    def is_game_installed(self, game_id: str) -> bool:
        if not self.current_user:
            return False
        email = self.current_user["email"].lower()
        for item in self.db.get("installed", []):
            if (
                item.get("user_email", "").lower() == email
                and item.get("game_id") == game_id
            ):
                return True
        return False

    def _mark_game_installed(self, game_id: str, game_dir: str) -> None:
        if not self.current_user:
            return
        email = self.current_user["email"].lower()
        installed_list = self.db.setdefault("installed", [])
        for item in installed_list:
            if (
                item.get("user_email", "").lower() == email
                and item.get("game_id") == game_id
            ):
                item["path"] = game_dir
                item["installed_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
                return
        installed_list.append(
            {
                "user_email": self.current_user["email"],
                "game_id": game_id,
                "path": game_dir,
                "installed_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            }
        )

    def _get_saved_game_path(self, game_id: str) -> str:
        if not self.current_user:
            return ""
        saved_paths = self.db.get("game_paths", {})
        user_key = f"{self.current_user['email'].lower()}::{game_id}"
        return saved_paths.get(user_key, "")

    def render_auth_screen(self, mode: str = "register") -> None:
        self.clear_window()

        outer = tk.Frame(self.root, bg="#0b0e14")
        outer.pack(fill="both", expand=True)

        card = tk.Frame(
            outer,
            bg="#131822",
            highlightbackground="#232c3d",
            highlightthickness=1,
            padx=36,
            pady=32,
        )
        card.place(relx=0.5, rely=0.5, anchor="center", width=430)

        tk.Label(
            card,
            text=BRAND_NAME,
            font=("Segoe UI", 22, "bold"),
            fg="#60a5fa",
            bg="#131822",
        ).pack(anchor="w")

        is_register = mode == "register"
        tk.Label(
            card,
            text="Ro'yxatdan o'tish" if is_register else "Akkauntga kirish",
            font=("Segoe UI", 16, "bold"),
            fg="#f8fafc",
            bg="#131822",
        ).pack(anchor="w", pady=(10, 4))

        tk.Label(
            card,
            text=(
                "O'zbekcha o'yin tarjimalarini yuklab olish uchun akkaunt oching"
                if is_register
                else "Davom etish uchun email va parolingizni kiriting"
            ),
            font=("Segoe UI", 10),
            fg="#94a3b8",
            bg="#131822",
            wraplength=355,
            justify="left",
        ).pack(anchor="w", pady=(0, 18))

        name_entry = None
        if is_register:
            tk.Label(
                card,
                text="Ismingiz",
                font=("Segoe UI", 10),
                fg="#cbd5e1",
                bg="#131822",
            ).pack(anchor="w")
            name_entry = tk.Entry(
                card,
                font=("Segoe UI", 11),
                bg="#0d1118",
                fg="#f8fafc",
                insertbackground="#f8fafc",
                relief="flat",
                highlightbackground="#2a3447",
                highlightthickness=1,
            )
            name_entry.pack(fill="x", ipady=8, pady=(4, 12))

        tk.Label(
            card,
            text="Email manzilingiz",
            font=("Segoe UI", 10),
            fg="#cbd5e1",
            bg="#131822",
        ).pack(anchor="w")
        email_entry = tk.Entry(
            card,
            font=("Segoe UI", 11),
            bg="#0d1118",
            fg="#f8fafc",
            insertbackground="#f8fafc",
            relief="flat",
            highlightbackground="#2a3447",
            highlightthickness=1,
        )
        email_entry.pack(fill="x", ipady=8, pady=(4, 12))

        tk.Label(
            card,
            text="Parol",
            font=("Segoe UI", 10),
            fg="#cbd5e1",
            bg="#131822",
        ).pack(anchor="w")
        password_entry = tk.Entry(
            card,
            font=("Segoe UI", 11),
            show="*",
            bg="#0d1118",
            fg="#f8fafc",
            insertbackground="#f8fafc",
            relief="flat",
            highlightbackground="#2a3447",
            highlightthickness=1,
        )
        password_entry.pack(fill="x", ipady=8, pady=(4, 18))

        def submit_form() -> None:
            email = email_entry.get().strip()
            password = password_entry.get().strip()

            if not email or not password:
                messagebox.showwarning("Diqqat", "Email va parolni to'ldiring!")
                return

            if is_register:
                name = name_entry.get().strip() if name_entry else ""
                if not name:
                    messagebox.showwarning("Diqqat", "Ismingizni kiriting!")
                    return

                for existing in self.db["users"]:
                    if existing.get("email", "").lower() == email.lower():
                        messagebox.showerror(
                            "Xatolik",
                            "Bu email bilan allaqachon ro'yxatdan o'tilgan. 'Kirish' bo'limidan kiring.",
                        )
                        return

                new_user = {
                    "name": name,
                    "email": email,
                    "password_hash": hash_password(password),
                    "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                }
                self.db["users"].append(new_user)
                save_db(self.db)
                self.current_user = new_user
                save_session(email)
                self.render_main_screen()
            else:
                pw_hash = hash_password(password)
                for user in self.db["users"]:
                    if (
                        user.get("email", "").lower() == email.lower()
                        and user.get("password_hash") == pw_hash
                    ):
                        self.current_user = user
                        save_session(user["email"])
                        self.render_main_screen()
                        return
                messagebox.showerror("Xatolik", "Email yoki parol noto'g'ri!")

        btn_text = "Ro'yxatdan o'tish" if is_register else "Kirish"
        tk.Button(
            card,
            text=btn_text,
            font=("Segoe UI", 11, "bold"),
            bg="#3b82f6",
            fg="#ffffff",
            activebackground="#2563eb",
            activeforeground="#ffffff",
            relief="flat",
            cursor="hand2",
            command=submit_form,
        ).pack(fill="x", ipady=9)

        switch_row = tk.Frame(card, bg="#131822")
        switch_row.pack(pady=(16, 0))

        tk.Label(
            switch_row,
            text="Akkauntingiz bormi? " if is_register else "Akkauntingiz yo'qmi? ",
            font=("Segoe UI", 10),
            fg="#94a3b8",
            bg="#131822",
        ).pack(side="left")

        switch_btn = tk.Button(
            switch_row,
            text="Kirish" if is_register else "Ro'yxatdan o'tish",
            font=("Segoe UI", 10, "bold", "underline"),
            fg="#60a5fa",
            bg="#131822",
            activeforeground="#93c5fd",
            activebackground="#131822",
            bd=0,
            cursor="hand2",
            command=lambda: self.render_auth_screen(
                mode="login" if is_register else "register"
            ),
        )
        switch_btn.pack(side="left")

    def logout(self) -> None:
        self.current_user = None
        save_session(None)
        self.render_auth_screen(mode="login")

    def open_stats_window(self) -> None:
        win = tk.Toplevel(self.root)
        win.title(f"{BRAND_NAME} — Statistika")
        win.geometry("420x260")
        win.configure(bg="#131822")
        win.resizable(False, False)

        users_count = len(self.db.get("users", []))
        sales_count = len(self.db.get("purchases", []))
        my_count = len(self.get_user_purchased_ids())

        tk.Label(
            win,
            text=f"{BRAND_NAME} Statistikasi",
            font=("Segoe UI", 15, "bold"),
            fg="#f8fafc",
            bg="#131822",
        ).pack(pady=(22, 14))

        info_text = (
            f"Versiya: {APP_VERSION}\n"
            f"Jami foydalanuvchilar: {users_count}\n"
            f"Jami sotuvlar: {sales_count}\n"
            f"Sizning tarjimalaringiz: {my_count}"
        )
        tk.Label(
            win,
            text=info_text,
            font=("Segoe UI", 11),
            fg="#cbd5e1",
            bg="#131822",
            justify="center",
        ).pack(pady=8)

        tk.Button(
            win,
            text="Yopish",
            font=("Segoe UI", 10, "bold"),
            bg="#2563eb",
            fg="#ffffff",
            relief="flat",
            padx=20,
            pady=6,
            cursor="hand2",
            command=win.destroy,
        ).pack(pady=(16, 0))

    def _deploy_mod_files(self, game_id: str, target_dir: str) -> tuple[int, str]:
        mod_source = os.path.join(MODS_DIR, game_id)
        if not os.path.isdir(mod_source):
            return 0, f"Mod papkasi topilmadi: {mod_source}"

        copied_count = 0
        for root_dir, _, files in os.walk(mod_source):
            rel_path = os.path.relpath(root_dir, mod_source)
            dest_dir = target_dir if rel_path == "." else os.path.join(target_dir, rel_path)
            os.makedirs(dest_dir, exist_ok=True)
            for fname in files:
                src_file = os.path.join(root_dir, fname)
                dst_file = os.path.join(dest_dir, fname)
                shutil.copy2(src_file, dst_file)
                copied_count += 1

        return copied_count, ""

    def buy_or_download_game(self, game: dict, already_bought: bool) -> None:
        if not self.current_user:
            return

        if not already_bought:
            self.db["purchases"].append(
                {
                    "user_email": self.current_user["email"],
                    "game_id": game["id"],
                    "game_title": game["title"],
                    "price": game["price"],
                    "bought_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                }
            )
            save_db(self.db)
            messagebox.showinfo(
                "Muvaffaqiyatli",
                f"'{game['title']}' tarjimasi akkauntingizga qo'shildi!\n"
                f"Endi 'Yuklab olish' tugmasini bosib o'yin papkasini tanlang.",
            )
            self.render_main_screen()
            return

        previous_dir = self._get_saved_game_path(game["id"])
        target_dir = filedialog_ask_dir(initial_dir=previous_dir)
        if not target_dir:
            return

        copied_count, err = self._deploy_mod_files(game["id"], target_dir)
        if err:
            messagebox.showerror("Xatolik", err)
            return

        saved_paths = self.db.setdefault("game_paths", {})
        user_key = f"{self.current_user['email'].lower()}::{game['id']}"
        saved_paths[user_key] = target_dir
        self._mark_game_installed(game["id"], target_dir)
        save_db(self.db)

        self.render_main_screen()
        messagebox.showinfo(
            "Tayyor",
            f"Yuklab oldingiz!\n\n"
            f"O'yinga kirsangiz bo'ladi. Hurmat bilan Begzodaka",
        )

    def render_main_screen(self) -> None:
        self.clear_window()

        topbar = tk.Frame(self.root, bg="#10151f", padx=24, pady=12)
        topbar.pack(fill="x")

        tk.Label(
            topbar,
            text=BRAND_NAME,
            font=("Segoe UI", 18, "bold"),
            fg="#60a5fa",
            bg="#10151f",
        ).pack(side="left")

        search_entry = tk.Entry(
            topbar,
            textvariable=self.search_var,
            font=("Segoe UI", 10),
            bg="#182030",
            fg="#f8fafc",
            insertbackground="#f8fafc",
            relief="flat",
            width=28,
        )
        search_entry.pack(side="left", padx=(24, 0), ipady=6)

        user_box = tk.Frame(topbar, bg="#161d2b", padx=12, pady=6)
        user_box.pack(side="right")

        user_name = self.current_user.get("name", "Foydalanuvchi") if self.current_user else ""
        user_email = self.current_user.get("email", "") if self.current_user else ""

        tk.Label(
            user_box,
            text=f"{user_name} ({user_email})",
            font=("Segoe UI", 9, "bold"),
            fg="#e2e8f0",
            bg="#161d2b",
        ).pack(side="left", padx=(0, 10))

        tk.Button(
            user_box,
            text="Chiqish",
            font=("Segoe UI", 9, "bold"),
            bg="#1e293b",
            fg="#cbd5e1",
            relief="flat",
            padx=8,
            pady=3,
            cursor="hand2",
            command=self.logout,
        ).pack(side="left")

        if self.update_available:
            tk.Button(
                topbar,
                text=f"Obnovit ({self.latest_version})",
                font=("Segoe UI", 10, "bold"),
                bg="#16a34a",
                fg="#ffffff",
                relief="flat",
                padx=14,
                pady=6,
                cursor="hand2",
                command=self.start_update,
            ).pack(side="right", padx=(0, 12))

        tk.Button(
            topbar,
            text="Statistika",
            font=("Segoe UI", 10, "bold"),
            bg="#1e293b",
            fg="#f8fafc",
            relief="flat",
            padx=14,
            pady=6,
            cursor="hand2",
            command=self.open_stats_window,
        ).pack(side="right", padx=(0, 12))

        banner = tk.Frame(
            self.root,
            bg="#0d121b",
            highlightbackground="#1b2434",
            highlightthickness=1,
            padx=24,
            pady=10,
        )
        banner.pack(fill="x")

        tk.Label(
            banner,
            text=f"{BRAND_NAME} Launcher v{APP_VERSION} — O'zbek tilidagi o'yin tarjimalari markazi",
            font=("Segoe UI", 10),
            fg="#cbd5e1",
            bg="#0d121b",
        ).pack(side="left")

        users_count = len(self.db.get("users", []))
        sales_count = len(self.db.get("purchases", []))
        tk.Label(
            banner,
            text=f"Foydalanuvchilar: {users_count} | Sotuvlar: {sales_count}",
            font=("Segoe UI", 10, "bold"),
            fg="#60a5fa",
            bg="#0d121b",
        ).pack(side="right")

        header_row = tk.Frame(self.root, bg="#0b0e14", padx=28, pady=20)
        header_row.pack(fill="x")

        left_titles = tk.Frame(header_row, bg="#0b0e14")
        left_titles.pack(side="left")

        tk.Label(
            left_titles,
            text="O'yin tarjimalari",
            font=("Segoe UI", 22, "bold"),
            fg="#f8fafc",
            bg="#0b0e14",
        ).pack(anchor="w")

        tk.Label(
            left_titles,
            text="Tarjimani bir marta sotib oling va o'yin papkasiga avtomatik o'rnating.",
            font=("Segoe UI", 10),
            fg="#94a3b8",
            bg="#0b0e14",
        ).pack(anchor="w", pady=(4, 0))

        purchased_ids = self.get_user_purchased_ids()
        available_games = [g for g in GAMES_CATALOG if g["status"] == "available"]
        my_count = len(purchased_ids)
        not_bought_count = max(0, len(available_games) - my_count)

        filter_box = tk.Frame(header_row, bg="#131822", padx=4, pady=4)
        filter_box.pack(side="right")

        filters = [
            ("all", f"Hammasi {len(GAMES_CATALOG)}"),
            ("mine", f"Mening tarjimalarim {my_count}"),
            ("unbought", f"Sotib olinmagan {not_bought_count}"),
        ]
        for key, label in filters:
            is_active = self.active_filter == key
            tk.Button(
                filter_box,
                text=label,
                font=("Segoe UI", 9, "bold"),
                bg="#f8fafc" if is_active else "#131822",
                fg="#0f172a" if is_active else "#94a3b8",
                relief="flat",
                padx=10,
                pady=6,
                cursor="hand2",
                command=lambda k=key: self._set_filter(k),
            ).pack(side="left", padx=2)

        cards_container = tk.Frame(self.root, bg="#0b0e14", padx=28)
        cards_container.pack(fill="both", expand=True)

        query = self.search_var.get().strip().lower()
        filtered_games = []
        for game in GAMES_CATALOG:
            is_bought = game["id"] in purchased_ids
            if self.active_filter == "mine" and not is_bought:
                continue
            if self.active_filter == "unbought" and (
                is_bought or game["status"] != "available"
            ):
                continue
            if query and query not in game["title"].lower() and query not in game["genre"].lower():
                continue
            filtered_games.append(game)

        col = 0
        for game in filtered_games:
            is_bought = game["id"] in purchased_ids
            is_soon = game["status"] == "coming_soon"
            is_installed = is_bought and self.is_game_installed(game["id"])

            card = tk.Frame(
                cards_container,
                bg="#131822",
                highlightbackground="#222b3d",
                highlightthickness=1,
                width=245,
                height=320,
            )
            card.grid(row=0, column=col, padx=(0, 16), pady=8, sticky="n")
            card.grid_propagate(False)

            top_banner = tk.Frame(card, bg=game["accent"], height=120)
            top_banner.pack(fill="x")
            top_banner.pack_propagate(False)

            badge_text = "✓ Sotib olingan" if is_bought else game["price"]
            tk.Label(
                top_banner,
                text=badge_text,
                font=("Segoe UI", 9, "bold"),
                bg="#0b0e14",
                fg="#f8fafc",
                padx=8,
                pady=3,
            ).pack(anchor="nw", padx=10, pady=10)

            body = tk.Frame(card, bg="#131822", padx=14, pady=12)
            body.pack(fill="both", expand=True)

            tk.Label(
                body,
                text=game["title"],
                font=("Segoe UI", 12, "bold"),
                fg="#f8fafc",
                bg="#131822",
                wraplength=215,
                justify="left",
            ).pack(anchor="w")

            tk.Label(
                body,
                text=game["genre"],
                font=("Segoe UI", 9),
                fg="#94a3b8",
                bg="#131822",
                wraplength=215,
                justify="left",
            ).pack(anchor="w", pady=(4, 0))

            bottom_box = tk.Frame(body, bg="#131822")
            bottom_box.pack(side="bottom", fill="x")

            if is_soon:
                tk.Button(
                    bottom_box,
                    text="Tez kunda",
                    font=("Segoe UI", 10, "bold"),
                    bg="#1e293b",
                    fg="#94a3b8",
                    relief="flat",
                    state="disabled",
                    cursor="arrow",
                ).pack(fill="x", ipady=7)
            elif is_installed:
                tk.Label(
                    bottom_box,
                    text="O'yinga kirsangiz bo'ladi.\nHurmat bilan Begzodaka",
                    font=("Segoe UI", 9, "bold"),
                    fg="#86efac",
                    bg="#0f291a",
                    padx=8,
                    pady=8,
                    justify="center",
                ).pack(fill="x")
            elif is_bought:
                tk.Button(
                    bottom_box,
                    text="↓ Yuklab olish",
                    font=("Segoe UI", 10, "bold"),
                    bg="#93c5fd",
                    fg="#0f172a",
                    relief="flat",
                    cursor="hand2",
                    command=lambda g=game: self.buy_or_download_game(g, True),
                ).pack(fill="x", ipady=7)
            else:
                tk.Button(
                    bottom_box,
                    text=f"Sotib olish · {game['price']}",
                    font=("Segoe UI", 10, "bold"),
                    bg="#2563eb",
                    fg="#ffffff",
                    relief="flat",
                    cursor="hand2",
                    command=lambda g=game: self.buy_or_download_game(g, False),
                ).pack(fill="x", ipady=7)

            col += 1

    def _set_filter(self, key: str) -> None:
        self.active_filter = key
        self.render_main_screen()


def filedialog_ask_dir(initial_dir: str = "") -> str | None:
    try:
        from tkinter import filedialog
        opts = {"title": "O'yin papkasini tanlang"}
        if initial_dir and os.path.isdir(initial_dir):
            opts["initialdir"] = initial_dir
        return filedialog.askdirectory(**opts) or None
    except Exception:
        return None


def main() -> None:
    root = tk.Tk()
    BegzodakaVoiceLauncher(root)
    root.mainloop()


if __name__ == "__main__":
    main()